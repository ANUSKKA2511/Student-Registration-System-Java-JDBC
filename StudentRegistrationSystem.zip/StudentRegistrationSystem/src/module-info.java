/**
 * 
 */
/**
 * 
 */
module StudentRegistrationSystem {
	requires java.sql;
}