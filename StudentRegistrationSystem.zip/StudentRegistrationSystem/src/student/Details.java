package student;

import java.sql.*;
import java.util.Scanner;
import java.sql.Connection;

public class Details {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Roll Number: ");
        int roll = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Department: ");
        String dept = sc.nextLine();

        String url = "jdbc:mysql://localhost:3306/student_db";
        String user = "your_username";//your username to be entered
        String password = "you_password";//your password to be entered

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(url, user, password);

            // Prepare SQL query
            String sql = "INSERT INTO students (name, roll, dept) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, name);
            pstmt.setInt(2, roll);
            pstmt.setString(3, dept);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Student details inserted successfully!");
            } else {
                System.out.println("Failed to insert student details.");
            }

        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database error!");
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            sc.close();
        }
    }
}

